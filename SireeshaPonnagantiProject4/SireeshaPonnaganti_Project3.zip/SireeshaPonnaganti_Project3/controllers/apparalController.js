const model = require('../models/apparal');

exports.apparals = (req, res) => {
    console.log('in /apparals');
    model.find()
    .then(apparals => res.render('./apparal/apparals.ejs', {apparals}))
    .catch(err=>next(err));
}

exports.apparalDetails = (req, res, next) => {
    let id = req.params.id;

    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid apparal id');
        err.status = 400;
        return next(err);
    }

    model.findById(id)
    .then(apparal => {
        if (apparal) {
            res.render('./apparal/apparalDetail.ejs', { apparal });
        } else {
            let err = new Error('Apparal not available in the closet -- ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));    
}

exports.create = (req, res, next) => {
    let newApparal = new model(req.body);
    newApparal.save()
    .then(() => res.redirect('/apparals'))
    .catch(err => {
        if(err.name === 'ValidationError' ) {
            err.status = 400;
        }
        next(err);
    })
}

exports.newApparal = (req, res) => {
    res.render('./apparal/newApparal.ejs');
}

exports.update = (req, res, next) => {
    let apparal = req.body;
    let id = req.params.id;

    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid apparal id');
        err.status = 400;
        return next(err);
    }

    model.findByIdAndUpdate(id, apparal, {useFindAndModify: false, runValidators: true})
    .then(apparal=>{
        if(apparal) {
            res.redirect('/apparals/'+req.params.id);
        
        } else {
            let err = new Error ("No such apparal in closet");
            err.status = 404;
            next(err);
        }
    })
    .catch(err => {
        if(err.name === 'ValidationError' ) {
            err.status = 400;
        }
        next(err);
    })

}

exports.editapparal = (req, res, next) => {
    let id = req.params.id;

    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid apparal id');
        err.status = 400;
        return next(err);
    }


    model.findById(id)
    .then(apparal => {
        if (apparal) {
            res.render('./apparal/edit.ejs', { apparal });
        } else {
            let err = new Error('Cannot find a apparal with ID ' + id);
            err.status = 404;
            next(err);
        }
    })
    
}

exports.deleteapparal = (req, res)=>{
    let id = req.params.id;

    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid apparal id');
        err.status = 400;
        return next(err);
    }
    
    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(apparal => {
        if(apparal){
            res.redirect('/apparals');
        }else{
            let err = new Error ("Apparal Delete out of Bounds");
            err.status = 404;
            next(err);
        }
    })
}