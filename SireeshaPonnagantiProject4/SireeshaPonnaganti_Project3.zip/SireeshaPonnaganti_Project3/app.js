//require modules

const express = require('express');
const morgan = require('morgan');
const mainRoute = require('./routes/mainRoutes');
const apparalRoute = require('./routes/apparalRoutes');
const methodOverride = require('method-override');
const mongoose = require('mongoose');


//create app
const app = express();

//configure app
let port = 3000;
let host = 'localhost';
app.set('view engine', 'ejs');

//connect to database
mongoose.connect('mongodb://127.0.0.1:27017/demos')
.then(() => {
    app.listen(port, host, () => {
        console.log("Initiated the app -->", host,port)
    })
})
.catch(err => console.log(err.message));

//mount the middleware 
app.use(express.static('public'))
app.use(express.urlencoded({ extended: true }));
app.use(morgan('tiny'));
app.use(methodOverride('_method'));
app.use('/', mainRoute);
app.use('/', apparalRoute);


//set up routes

app.get('/newConnection', (req, res) => {
console.log("Check");
res.render('./story/newConnection');
});

app.use((req, res, next) => {
    let err = new Error('The server cannot locate' + req.url);
    err.status = 404;
    next(err);
});

app.use((err, req, res, next) => {
    console.log(err.stack);
    if (!err.status) {
        err.status = 500;
        err.message = ("Internal Server Error");
    }

    res.status(err.status);
    res.render('error', { error: err });
});

