const express = require('express');
const controller = require('../controllers/apparalController');

const router = express.Router();

router.get('/apparals', controller.apparals);

router.get('/apparals/:id', controller.apparalDetails);

router.post('/apparals', controller.create);

router.get('/newApparal', controller.newApparal);

router.put('/apparals/:id', controller.update);

router.get('/apparals/:id/edit', controller.editapparal);

router.delete('/apparals/:id', controller.deleteapparal);




module.exports = router;