const model = require('../models/user');

exports.new = (req, res)=>{
    res.render('./user/new');
};
/**
 * Signup Method
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.create = (req, res, next)=>{
    let user = new model(req.body);
    user.save()
    .then(()=>res.redirect('/users/login'))
    .catch(err=>{
        if(err.name === 'ValidationError'){
            req.flash('error',err.message);
            return res.redirect('/users/new');
        }
        if(err.code === 11000){
            req.flash('error','This Email address has already been used');
            return res.redirect('/users/new');
        }
        next(err);
    });
};

exports.login = (req, res)=>{
    res.render('./user/login');
};
/**
 * User authentication 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.authenticate = (req, res, next)=>{
    let email = req.body.email;
    let password = req.body.password;
    model.findOne({email:email})
    .then(user=>{
        if(user){
            //If user exists in database
            user.comparePassword(password)
            .then(result=>{
                 if(result){
                     req.session.user = user._id;
                     req.flash('success','loggedin Successfully!!!')
                     res.redirect('/users/profile');
                 }else{
                    req.flash('error','Wrong password!');
                    res.redirect('/users/login');
                 }
            })
        }else{
            req.flash('error','Wrong email address!')
            res.redirect('/users/login');
        }
    })
    .catch(err=>next(err));
};
/**
 * Get user profile 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.profile = (req, res, next)=>{
    let id = req.session.user;
    model.findById(id)
    .then(user=>res.render('./user/profile',{user}))
    .catch(err=>next(err));
};
/**
 * Logout the user 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.logout = (req, res, next)=>{
    req.session.destroy(err=>{
        if(err)
            return next(err);
        else
            res.redirect('/');
    });
};