const express = require('express');
const controller = require('../controllers/userController');

const router = express.Router();

//GET /users/new: send html form for new user creation
router.get('/new', controller.new);

//POST /users: new user creation
router.post('/', controller.create);

//GET /users/login: send html form for user login
router.get('/login', controller.login);

//POST /users: user authentication
router.post('/login', controller.authenticate);

//GET /users/profile: show user details
router.get('/profile', controller.profile);

//GET /users/logout: logout user
router.get('/logout', controller.logout);

module.exports = router;