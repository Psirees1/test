const http = require("http");
const fs = require("fs");
const host = 'localhost';
const port = 8080;
const server = http.createServer((req,res) => {
    res.setHeader('Content-Type', 'text/html');
    let view_path = './views/';
    res.statusCode = 200;
    if (req.url === '/') {
        view_path = view_path + 'index.html';//This will display index file as the default page
    }else if (req.url === '/about'){
        view_path = view_path + 'about.html';//This will fetch the about page
    }else if(req.url === '/contact'){
        view_path = view_path + 'contact.html';//This will fetch the contact page
    }else{
        res.statusCode = 404;
        view_path = view_path + '404.html';//This will fetch the error page
    }

    fs.readFile(view_path, (err, data) => {
        if (err){
            console.log(err);
            res.end();
        }else{
            res.write(data);
            res.end();
        }
    });
});
server.listen(port,host, () =>{
    console.log('Server running succesfully on the port', port);
});