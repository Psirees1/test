const rateLimit = require("express-rate-limit");

exports.LogInLimiter = rateLimit({
    windowMs: 60*1000,
    max:6,
    handler:(req,res, next)=>{
        let err = new Error("Try again later, you exceeded the number of attempts");
        err.status = 429;
        return next(err);
    }
});