const { DateTime } = require("luxon");
const { v4: uuidv4 } = require('uuid');
const stories = [
    {
        id:'1',
        title:"The Lottery" ,
        content:"The Lottery is a short story written by Shirley Jackson, first published in the June 26, 1948, issue of The New Yorker. The story describes a fictional small town which observes an annual tradition known as the lottery, in which a member of the community is selected by chance and stoned",
        author:'Shirley Jackson',
        createdAt:DateTime.now().toLocaleString(DateTime.DATETIME_SHORT),
    },
    {
        id:'2',
        title:'To Build a Fire',
        content:"'To Build a Fire' is a short story by American author Jack London. There are two versions of this story. The first one was published in 1902, and the other was published in 1908. The story written in 1908 has become an often anthologized classic, while the 1902 story is less well known",
        author:'Jack London',
        createdAt:DateTime.local(1902,2,5,13,29).toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id:'3',
        title:'The Library of Babel',
        content:"'The Library of Babel' is a short story by Argentine author and librarian Jorge Luis Borges, conceiving of a universe in the form of a vast library containing all possible 410-page books of a certain format and character set",
        author:'Alexa',
        createdAt:DateTime.local(1941,3,6,12,22).toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id:'4',
        title:'The Veldt',
        content:"'The Veldt' is a science fiction short story by American author Ray Bradbury. Originally appearing as 'The World the Children Made' in the September 23, 1950 issue of The Saturday Evening Post, it was republished under its current name in the 1951 anthology The Illustrated Man",
        author:'Jorge Luis Borges',
        createdAt:DateTime.local(1941,11,8,11,32).toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id:'5',
        title:'The Tell - Tale Heart',
        content:"'The Tell-Tale Heart' is a short story by American writer Edgar Allan Poe, first published in 1843. It is related by an unnamed narrator who endeavors to convince the reader of the narrator's sanity while simultaneously describing a murder the narrator committed",
        author:'Edgar Allan Poe',
        createdAt:DateTime.local(1843,15,8,25,22).toLocaleString(DateTime.DATETIME_SHORT)
    }
];

exports.find = () => stories;

exports.findById = id => stories.find(story => story.id === id);

exports.save = function (story) {
    story.id = uuidv4();
    story.createdAt=DateTime.now().toLocaleString(DateTime.DATETIME_SHORT);
    stories.push(story);
};

exports.updateById = function (id, newStory) {
    let story = stories.find(story => story.id === id);
    if(story){
        story.title = newStory.title;
        story.content = newStory.content;
        return true;
    }else {
        return false;
    }
};

exports.deleteById = function (id) {
    let index = stories.findIndex(story => story.id === id);
    console.log(index);
    if(index !== -1){
        stories.splice(index,1);
        return true;
    }else {
        return false;
    }
};  