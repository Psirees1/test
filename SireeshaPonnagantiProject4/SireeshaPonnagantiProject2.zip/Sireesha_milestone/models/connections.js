const { DateTime } = require("luxon");
const { v4: uuidv4 } = require('uuid')
const {isEmpty} = require('lodash');


const connections = [
    {
        connectionId: '1',
        connectionName: 'Career Fair',
        connectionTopic: 'Formals',
        details: "Free Formals to all the students (First come first serve) ",
        date: DateTime.local(2021, 04, 22).toISODate(),
        startTime: '10:30',
        endTime: '12:30',
        hostName: 'Department of Computer Science',
        image: '/images/formal.jpg',
        location: 'Student Union Center'
    },
    {
        connectionId: '2',
        connectionName: 'Student Orientation',
        connectionTopic: 'Fulltime',
        details: 'All types of Fulltime job attires are available',
        date: DateTime.local(2021, 05, 25).toISODate(),
        startTime: '2:00',
        endTime: '6:00',
        hostName: 'Student Organization',
        image: '/images/fulltime.jpg',
        location: 'Clock tower'
    },
    
    {
        connectionId: '3',
        connectionName: 'Student Orientation',
        connectionTopic: 'Partime',
        details: 'All types of patime job attires are available',
        date: DateTime.local(2021, 06, 22).toISODate(),
        startTime: '2:00',
        endTime: '6:00',
        hostName: 'Student Organization',
        image: '/images/partime.jpg',
        location: 'Cone Hall'
    },
    {
        connectionId: '4',
        connectionName: 'Career Fair',
        connectionTopic: 'Semi Formals',
        details: "SemiFormals on the carrer fair day ",
        date: DateTime.local(2021, 04, 22).toISODate(),
        startTime: '10:30',
        endTime: '12:30',
        hostName: 'Department of Computer Science',
        image: '/images/semiformals.png',
        location: 'Student Union Center'
    },
    {
        connectionId: '5',
        connectionName: 'Career Fair',
        connectionTopic: 'Blazers',
        details: "Suites to all the college students on the event day",
        date: DateTime.local(2021, 04, 22).toISODate(),
        startTime: '10:30',
        endTime: '12:30',
        hostName: 'Department of Computer Science',
        image: '/images/blazers.png',
        location: 'Student Union Center'
    },
    {
        connectionId: '6',
        connectionName: 'Student Orientation',
        connectionTopic: 'Internship',
        details: 'Get ready for the intership program',
        date: DateTime.local(2021, 05, 25).toISODate(),
        startTime: '2:00',
        endTime: '6:00',
        hostName: 'Student Organization',
        image: '/images/internship.jpg',
        location: 'Clock tower'
    },
]

exports.allconnections = function () {
    return connections;
}

exports.findById = id => connections.find(connection => connection.connectionId === id);

exports.save = (connection) => {
    connection.connectionId = uuidv4();
    connections.push(connection);
};

exports.updatebyId = function (id, newConnection) {
    let connection = connections.find(connection => connection.connectionId === id);
    if (connection) {
        connection.connectionName = newConnection.connectionName;
        connection.connectionTopic = newConnection.connectionTopic;
        connection.date = newConnection.date;
        connection.startTime = newConnection.startTime;
        connection.endTime = newConnection.endTime;
        connection.location = newConnection.location;
        connection.image = newConnection.image;
        connection.details = newConnection.details;
        connection.hostName = newConnection.hostName;
        return true;
    } else {
        return false;
    }
};

exports.deletebyId = function (id) {
    let index = connections.findIndex(connection => connection.connectionId === id);
    if (index !== -1) {
        connections.splice(index, 1);
        return true;
    } else {
        return false;
    }
};


exports.allconnectionsGroupByName = function () {
    let allconnections = connections.reduce((r, a) => {
        r[a.connectionName] = [...r[a.connectionName] || [], a];
        return r;
    }, {});
    if (!isEmpty(allconnections))
        return allconnections;
    else return false;
}
