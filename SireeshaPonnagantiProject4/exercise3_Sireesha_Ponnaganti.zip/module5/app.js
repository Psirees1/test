const express = require('express');
const { v4: uuidv4 } = require('uuid');
const morgan = require('morgan');
const ejs = require('ejs');

const app = express();
//setting port number as 3000
let port = 3000;
//setting server as localhost
let host = 'localhost';

app.set('view engine', 'ejs');

//listimg the student records
let students = [
   { id: '1', name: 'Alice', major: 'Computer Science', gpa: 3.5},
    { id: '2', name: 'Bob', major: 'Biology', gpa: 3.2 },
    { id: '3', name: 'Charlie', major: 'Physics', gpa: 3.0}
];

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.use(morgan('tiny'));

app.get('/', (req, res) => {
    res.sendFile('./views/index.html', { root: __dirname });
});

//retrieving aal the student data 
app.get('/students', (req, res) => {
   // res.json(students);
   res.render('students',{students:students});
});

//taking the record of student that entered in create student page
app.post('/students', (req, res) => {
    //console.log(req.body);
    let student = req.body;
    student.id = uuidv4();
    students.push(student);
    res.redirect('/students');
});

//opens form that allow us to enter the student record
app.get('/students/create', (req, res) => {
    res.sendFile('./views/new.html', { root: __dirname });
});

//opens the particular record of a student based on ID
app.get('/students/:sid', (req, res) => {
    let id = req.params.sid;
    let student = students.find(element => element.id === id);
    res.render('student', {student: student});
});

//opens about page with details
app.get('/about', (req, res) => {
    res.send('About page');
});

//opens contact page that have contact details
app.get('/contact', (req, res) => {
    res.send('Contact page');
});


//opens contact-me page which internally triggers the contact page
app.get('/contact-me', (req, res) => {
    res.redirect(301, '/contact');
});

//declaring the next function, which triggers page not found for the links we dont write have pages data defined
app.use((req, res, next) => {
    res.status(404).send('Page cannot be found');
});

//Checking in console whether the server running on port
app.listen(port, host, () => {
    console.log('The server is running at port', port);
});