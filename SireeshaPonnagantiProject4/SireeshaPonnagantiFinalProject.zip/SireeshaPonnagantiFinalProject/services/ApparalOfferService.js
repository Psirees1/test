
const ApparalOffer = require('../models/apparalOffer');
exports.findByUserIdAndApparalId = (userId, tradeId) => {
  return ApparalOffer.findOne({ customer: userId, requestApparalTrade: tradeId });
};
exports.findBycustomerApparalIdOrrequestApparalTradeId = (tradeId) => {
  return ApparalOffer.findOne({ $or: [{customerApparal: tradeId}, { requestApparalTrade: tradeId}] }).populate("requestApparalTrade").populate("customerApparal");; 
};


exports.findByUserId = (userId) => {
  return ApparalOffer.find({ customer: userId }).populate("requestApparalTrade");
};
exports.findById = (id) => {
  return ApparalOffer.findOne({ _id: id }).populate("requestApparalTrade").populate("customerApparal");
};
exports.save = (offer) => {
  const apparalOffer = new ApparalOffer(offer);
  return apparalOffer.save();
}

exports.deleteByrequestApparalTradeIdAndcustomerApparalId = function (requestApparalTradeId, customerApparalId) {
  return ApparalOffer.findOneAndDelete({
    $or: [
        { $and: [{requestApparalTrade: requestApparalTradeId}, { customerApparal:customerApparalId}] },
        { $and: [{requestApparalTrade: customerApparalId}, { customerApparal:requestApparalTradeId}] },
    ]
  });
}
exports.deleteByCreatorIdAndcustomerApparalId = function (creatorId, customerApparalId) {
  return ApparalOffer.findOneAndDelete(
        { $and: [{creator: creatorId}, { customerApparal:customerApparalId}]},
  );
}