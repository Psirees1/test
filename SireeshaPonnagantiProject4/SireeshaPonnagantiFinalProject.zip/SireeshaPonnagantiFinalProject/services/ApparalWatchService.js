const ApparalWatch = require('../models/apparalWatch');
const ApparalOfferService = require('../services/ApparalOfferService');
const apparalWatchService = require('../services/ApparalWatchService');


exports.findByUserIdAndApparalId =  (userId,apparalID)=> {
    return  ApparalWatch.findOne({WishlistedBy:userId,WishlistedTrade:apparalID});
};
exports.findByUserId =(id)=>{
  return  ApparalWatch.find({WishlistedBy:id}).populate("WishlistedTrade");
}

exports.save = (newWatch)=> {
    const apparalWatch = new ApparalWatch(newWatch);
   return apparalWatch.save();
}

exports.deleteById = function (id) {
  return ApparalWatch.findByIdAndDelete(id);
}
exports.deleteByIdAndUserId = function (apparalID,userId) {
  return ApparalWatch.deleteMany({WishlistedTrade:apparalID,WishlistedBy:userId});
}
exports.deleteByApparalId = function (apparalID) {
  return ApparalWatch.deleteMany({WishlistedTrade:apparalID});
}
