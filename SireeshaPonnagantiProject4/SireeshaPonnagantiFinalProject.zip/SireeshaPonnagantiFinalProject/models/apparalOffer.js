const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const tradeOfferSchema = new Schema({
    creator: { type: Schema.Types.ObjectId, ref: 'User' },// create product to trade
    customerApparal:{ type: Schema.Types.ObjectId, ref: 'apparal' }, 
    customer:{ type: Schema.Types.ObjectId, ref: 'User' },
    requestApparalTrade:{ type: Schema.Types.ObjectId, ref: 'apparal' },
},
    { timestamps: true }
);
module.exports = mongoose.model('apparalOffer', tradeOfferSchema);


