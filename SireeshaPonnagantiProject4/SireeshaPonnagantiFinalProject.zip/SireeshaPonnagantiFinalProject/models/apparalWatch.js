const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const tradeWatchSchema = new Schema({
    WishlistedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    WishlistedTrade: { type: Schema.Types.ObjectId, ref: 'apparal' },
},
    { timestamps: true }
);

module.exports = mongoose.model('ApparalTradeWatch', tradeWatchSchema);
