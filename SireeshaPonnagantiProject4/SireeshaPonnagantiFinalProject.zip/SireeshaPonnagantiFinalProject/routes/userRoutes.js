const express = require('express');
const controller = require('../controllers/userController');
const { isGuest, isLoggedIn } = require('../middlewares/auth');
const {logInLimiter} = require('../middlewares/rateLimiters');
const {validateId,validateSignUpMiddleware, validateLogInMiddleware, validateResultMiddleware} = require('../middlewares/validator');
 
const router = express.Router();

//GET /user/new: send html form for creating a new user account

router.get('/new', isGuest, controller.new);

//POST /user: create a new user account

router.post('/', isGuest, validateSignUpMiddleware, validateResultMiddleware, controller.create);

//GET /user/login: send html for logging in
router.get('/login', isGuest, controller.getUserLogin);

//POST /user/login: authenticate user's login
router.post('/login', isGuest,logInLimiter, validateLogInMiddleware, validateResultMiddleware, controller.login);

//GET /user/profile: send user's profile page
router.get('/profile', isLoggedIn, controller.profile);

//POST /user/logout: logout a user
router.get('/logout', isLoggedIn, controller.logout);

router.delete('/watch/:id', validateId, isLoggedIn, controller.removeWishList)
router.post('/offer/:id', validateId, isLoggedIn, controller.makeAapparalOffer)
router.delete('/offer/:id', validateId, isLoggedIn, controller.cancelApparalOffer)
router.put('/offer/:id', validateId, isLoggedIn, controller.approveApparalOffer)
router.get('/apparal/offer/:id', validateId, isLoggedIn, controller.manageApparalOffer)
router.get('/apparals/:id', validateId, isLoggedIn, controller.showTrades)

module.exports = router;