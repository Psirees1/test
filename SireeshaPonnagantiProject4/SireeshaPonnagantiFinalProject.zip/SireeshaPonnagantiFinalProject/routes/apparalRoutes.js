const express = require('express');
const router = express.Router();
const apparalController = require('../controllers/apparalController');
const { isLoggedIn, isOwner } = require('../middlewares/auth');
const { validateId } = require('../middlewares/validator');
const{validateApparal,validateResultMiddleware} = require('../middlewares/validator');

//GET /apparals: send all apparals to the user
router.get('/', apparalController.index);

//GET /apparals/new: send html form for creating a new apparal
router.get('/new', isLoggedIn, apparalController.new);

//POST /apparals: create a new apparal
router.post('/', isLoggedIn, validateApparal, validateResultMiddleware, apparalController.create);

//GET /apparals/:id: send details of apparal identified by id
router.get('/:id', validateId, apparalController.show);

//GET /apparals/:id: send html form for editing an existing apparal
router.get('/:id/edit', validateId, isLoggedIn, isOwner, apparalController.edit);

//PUT /apparals/:id: update the apparal identified by id
router.put('/:id', validateId, isLoggedIn, isOwner,validateApparal, validateResultMiddleware, apparalController.update);

//DELETE /apparals/:id: delete the apparal identified by id
router.delete('/:id', validateId, isLoggedIn, isOwner, apparalController.delete);
router.post('/watch/:id', validateId, isLoggedIn, apparalController.addToWishList)
router.delete('/watch/:id', validateId, isLoggedIn, apparalController.removeToWishList)

module.exports=router;