const User = require('../models/user');
const Apparal = require('../models/apparal');
const apparalOfferService = require('../services/apparalOfferService');
const apparalWatchService = require('../services/ApparalWatchService');

exports.new = (req, res)=>{ 
    res.render('./user/new');
};

exports.create = (req, res, next)=>{
    let user = new User(req.body);
    user.save()
    .then(user=> {
        req.flash('success', 'You have successfully registered');
        res.redirect('/user/login');
    })
    .catch(err=>{
        if(err.name === 'ValidationError' ) {
            req.flash('error', err.message);  
            return res.redirect('/user/new');
        }

        if(err.code === 11000) {
            req.flash('error', 'Email has been used');  
            return res.redirect('/user/new');
        }
        
        next(err);
    }); 
};

exports.getUserLogin = (req, res, next) => {
    res.render('./user/login');
}

exports.login = (req, res, next)=>{
    let email = req.body.email;
    let password = req.body.password;

    User.findOne({ email: email })
    .then(user => {
        if (!user) {
            req.flash('error', 'Wrong email address');  
            res.redirect('/user/login');
        } else {
            user.comparePassword(password)
            .then(result=>{
                if(result) {
                    req.session.user = user._id;
                    req.session.firstName = user.firstName;
                    req.session.lastName = user.lastName;
                    req.flash('success', 'You have successfully logged in');
                    res.redirect('/user/profile');
                } else {
                    req.flash('error', 'Wrong password');      
                    res.redirect('/user/login');
                }
            })
            .catch(err => next(err));;     
        }     
    })
    .catch(err => next(err));
};

exports.profile = (req, res, next) => {
    let id = req.session.user;
    Promise.all([User.findById(id), Apparal.find({ Owner: id }), apparalOfferService.findByUserId(id), apparalWatchService.findByUserId(id)])
        .then(results => {
            const [user, apparals, apparalOffers, wishlistedTrade] = results;
            console.log(wishlistedTrade);
            res.render('./user/profile', { user, apparals, apparalOffers, wishlistedTrade })
        })
        .catch(err => next(err));
};


exports.logout = (req, res, next)=>{
    req.session.destroy(err=>{
        if(err) 
           return next(err);
       else
            res.redirect('/');  
    });
 };

 exports.makeAapparalOffer = async (req, res, next) => {
    let id = req.params.id;
    let tradeId = req.body.id
    let userId = req.session.user;
    try {
        let trade = await Apparal.findById(id).populate('Owner', '_id firstName lastName');
        if (!trade) {
            let err = new Error('No apparals with id ' + id + ' found for the offer');
            err.status = 404;
            next(err);
        } else {
            console.log(trade);
            let newApparalOffer = {
                creator: trade.Owner._id,
                requestApparalTrade: req.params.id, 
                customerApparal: tradeId,
                customer: userId,
            }
            let offerTrade = await apparalOfferService.save(newApparalOffer);
           await Apparal.findByIdAndUpdate(id,  { status: "In-Process Offer" }, { useFindAndModify: false, runValidators: true })
           await Apparal.findByIdAndUpdate(tradeId,  { status: "In-Process Offer" }, { useFindAndModify: false, runValidators: true })
            req.flash('success', 'Apparal has been requested Successfully!');
            res.redirect('/user/profile');
        }
    } catch (error) {
        next(error);
    }
};
exports.cancelApparalOffer = async (req, res, next) => {
    let id = req.params.id;
    let userId = req.session.user;
    try {
        let tradeOffer = await apparalOfferService.findById(id);
        console.log(tradeOffer);
        if (tradeOffer && (tradeOffer.creator == userId || tradeOffer.customer == userId)) {
            let trade = await apparalOfferService.deleteByrequestApparalTradeIdAndcustomerApparalId(tradeOffer.requestApparalTrade._id, 
                tradeOffer.customerApparal._id);
            await Apparal.findByIdAndUpdate(tradeOffer.customerApparal._id,  { status: "Available" }, { useFindAndModify: false, runValidators: true })
           await Apparal.findByIdAndUpdate(tradeOffer.requestApparalTrade._id,  { status: "Available" }, { useFindAndModify: false, runValidators: true })
            req.flash('success', 'Apparal has been cancelled Succesfully');
            res.redirect('/user/profile');
        } else {
            let err = new Error('User Not Authorised');
            err.status = 401;
            return next(err);
        }
    } catch (error) {
        next(error);
    }
};

exports.approveApparalOffer = async (req, res, next) => {
    let id = req.params.id;
    let userId = req.session.user;
    try {
        let tradeOffer = await apparalOfferService.findById(id);
        console.log(tradeOffer,userId);
        if (tradeOffer && tradeOffer.creator == userId) {
            let trade = await apparalOfferService.deleteByCreatorIdAndcustomerApparalId(tradeOffer.creator._id, tradeOffer.customerApparal._id);
            await Apparal.findByIdAndUpdate(tradeOffer.requestApparalTrade._id,  { status: "Traded" }, { useFindAndModify: false, runValidators: true })
           await Apparal.findByIdAndUpdate(tradeOffer.customerApparal._id,  { status: "Traded" }, { useFindAndModify: false, runValidators: true })
            req.flash('success', 'Apparal has been approved successfully!');
            res.redirect('/user/profile');
        } else {
            let err = new Error('User Not Authorised');
            err.status = 401;
            return next(err);
        }
    } catch (error) {
        next(error);
    }
};
exports.manageApparalOffer = async (req, res, next) => {
    let id = req.params.id;
    try {
        let tradeOffer = await apparalOfferService.findBycustomerApparalIdOrrequestApparalTradeId(id);
        if (!tradeOffer) {
            let err = new Error('No offer with id ' + id + ' found for the offer');
            err.status = 404;
            next(err);
        } else {
            res.render('./apparal/manageApparalOffer', { tradeOffer });
        }

    } catch (error) {
        err => next(err)
    }
};
exports.removeWishList = async (req, res, next) => {
    let id = req.params.id;
    let userId = req.session.user;
    try {
        let apparal = await Apparal.findById(id);
        console.log(apparal);
        if (!apparal) {
            let err = new Error('No trades with id ' + id + ' found for the wish list');
            err.status = 404;
            next(err);
        } else {
            let wishList = await apparalWatchService.deleteByIdAndUserId(id,userId);
            req.flash('success', 'The wishlist has been changed succesfully');
            res.redirect('/user/profile');
        }
    } catch (error) {
        next(error);
    }
};

exports.showTrades = async (req, res, next) => {
    let id = req.params.id;
    let userId = req.session.user;
    let apparal = await Apparal.findById(id);
    if (!apparal) {
        let err = new Error('No apparals with id ' + id + ' found for the offer');
        err.status = 404;
        next(err);
    } else {
    let availableTrades = await Apparal.find({ Owner: userId ,status:"Available"});
    console.log(availableTrades);
        res.render('./apparal/apparalOffer', { availableTrades, apparal });
    }
};




