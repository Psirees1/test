const Apparal = require('../models/apparal');
const { DateTime } = require("luxon");
const User = require('../models/user');
const apparalOfferService = require('../services/ApparalOfferService');
const apparalWatchService = require('../services/ApparalWatchService');

exports.index = (req, res, next) => {
    let categories = [];
    Apparal.distinct("topic", function(error, results){
        categories = results;
        Apparal.find()
        .then(apparals => res.render('./apparal/apparals', {apparals, categories}))
        .catch(err=>next(err));
    });
   
};

exports.new = (req, res) => {
    res.render('./apparal/newApparal');
};

exports.create = (req, res, next) => {
    console.log(req.body)
    let apparal = new Apparal(req.body);//create a new apparal document
    apparal.Owner = req.session.user;
    apparal.save()//insert the document to the database
    .then(apparal=> {
        req.flash('success', 'A new apparal has been created successfully');
        res.redirect('/apparals');
    })
    .catch(err=>{
        if(err.name === 'ValidationError'){
            req.flash('error', err.message);
            res.redirect('back');
        }else{
            next(err);
        }
    });
};

exports.show = async(req, res, next) => {
    let id = req.params.id;
    let userId = req.session.user;
    let WishlistedTrade = await apparalWatchService.findByUserIdAndApparalId(userId, id);
        let apparalOffers = await apparalOfferService.findByUserIdAndApparalId(userId, id);
    Apparal.findById(id).populate('Owner', 'firstName lastName')
    .then(apparal=>{
        if(apparal) {
            apparal.date = DateTime.fromSQL(apparal.date).toFormat('LLLL dd, yyyy');
            apparal.startTime = DateTime.fromSQL(apparal.startTime).toFormat('hh:mm a');
            apparal.endTime = DateTime.fromSQL(apparal.endTime).toFormat('hh:mm a');
            return res.render('./apparal/apparalDetail', {apparal, WishlistedTrade, apparalOffers});
        } else {
            let err = new Error('No apparal with id identified ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
};

exports.edit = (req, res, next) => {
    let id = req.params.id;
    Apparal.findById(id)
    .then(apparal=>{
        console.log(apparal)
        if(apparal) {

            return res.render('./apparal/apparalDetailEdit', {apparal});
        } else {
            let err = new Error('No apparal with id identified' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
};

exports.update = (req, res, next) => {
    let apparal = req.body;
    let id = req.params.id;
    Apparal.findByIdAndUpdate(id, apparal, {useFindAndModify: false, runValidators: true})
    .then(apparal=>{
        if(apparal) {
            req.flash('success', 'apparal has been successfully updated');
            res.redirect('/apparals/'+id);
        } else {
            let err = new Error('No apparal with id identified ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=> {
        if(err.name === 'ValidationError'){
            req.flash('error', err.message);
            res.redirect('back');
        }else{
            next(err);
        }
    });
};

exports.delete = async (req, res, next) => {
    let id = req.params.id;
    let tradeOffer = await apparalOfferService.findBycustomerApparalIdOrrequestApparalTradeId(id);
    console.log(tradeOffer);
    let wishList = await apparalWatchService.deleteByApparalId(id);
    if(tradeOffer){
        let trade = await apparalOfferService.deleteByrequestApparalTradeIdAndcustomerApparalId(tradeOffer.requestApparalTrade._id, tradeOffer.customerApparal._id);
        await Apparal.findByIdAndUpdate(tradeOffer.requestApparalTrade._id,  { status: "Available" }, { useFindAndModify: false, runValidators: true });
           await Apparal.findByIdAndUpdate(tradeOffer.customerApparal._id,  { status: "Available" }, { useFindAndModify: false, runValidators: true });      
    }
    Apparal.findByIdAndDelete(id, {useFindAndModify: false})
    .then(apparal =>{
        if(apparal) {
            res.redirect('/apparals');
        } else {
            let err = new Error('No apparal with id identified ' + id);
            err.status = 404;
            return next(err);
        }
    })
    .catch(err=>next(err));
};

exports.addToWishList = async (req, res, next) => {
    let id = req.params.id;
    let userId = req.session.user;
    try {
        let trade = await Apparal.findById(id);
        if (!trade) {
            let err = new Error('No trades with id ' + id + ' found for the wish list');
            err.status = 404;
            next(err);
        } else {
            let newWishList = {
                WishlistedBy: userId,
                WishlistedTrade: id
            }
            let wishList = await apparalWatchService.save(newWishList);
            req.flash('success', 'Your trade has been wishlisted Successfully!');
            res.redirect('/apparals/' + id);
        }
    } catch (error) {
        next(error);
    }
};

exports.removeToWishList = async (req, res, next) => {
    let id = req.params.id;
    let userId = req.session.user;
    try {
        let trade = await Apparal.findById(id);
        if (!trade) {
            let err = new Error('No trades with id ' + id + ' found for the wish list');
            err.status = 404;
            next(err);
        } else {
            let wishList = await apparalWatchService.deleteByIdAndUserId(id, userId);
            req.flash('success', 'You have removed your trade from Wishlist!');
            res.redirect('/apparals/' + id);
        }
    } catch (error) {
        next(error);
    }
};