const Story = require('../models/story');

/**
 * 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 * @returns 
 */
exports.isGuest = (req, res, next)=>{
    if(!req.session.user){
        return next();
    } else {
        req.flash('error','You are logged in already');
        return res.redirect('/users/profile');
    }
};

/**
 * 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 * @returns 
 */
exports.isLoggedIn = (req, res, next)=>{
    if(req.session.user){
        return next();
    } else {
        req.flash('error','Please login first!!!');
        return res.redirect('/users/login');
    }
};

/**
 * 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.isAuthor = (req, res, next)=>{
    let id = req.params.id;
    Story.findById(id)
    .then(story => {
        if(story){
            if(story.author == req.session.user){
                return next();
            } else {
                let err = new Error('Unauthorized  !!!');
                err.status = 401;
                return next(err);
            }
        }
    })
    .catch(err=>next(err));
};