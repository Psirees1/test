const Story = require('../models/story');
const model = require('../models/user');

exports.new = (req, res)=>{
    res.render('./user/new');
};
/**
 * Signup method
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.create = (req, res, next)=>{
    //res.send('Created a new story');
    let user = new model(req.body);//create a new story document
    user.save() //insert the document to the database
    .then(()=>res.redirect('/users/login'))
    .catch(err=>{
        if(err.name === 'ValidationError'){
            req.flash('error',err.message);
            return res.redirect('/users/new');
        }
        if(err.code === 11000){
            req.flash('error','Email address has been used');
            return res.redirect('/users/new');
        }
        next(err);
    });
};

exports.login = (req, res)=>{
    res.render('./user/login');
};
/**
 * user authentication method
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.authenticate = (req, res, next)=>{
    let email = req.body.email;
    let password = req.body.password;
    model.findOne({email:email})
    .then(user=>{
        if(user){
            //User present in the database
            user.comparePassword(password)
            .then(result=>{
                 if(result){
                     req.session.user = user._id;
                     req.flash('success','You have successfully logged in!')
                     res.redirect('/users/profile');
                 }else{
                    req.flash('error','Wrong password!');
                    res.redirect('/users/login');
                 }
            })
        }else{
            req.flash('error','Wrong email address!')
            res.redirect('/users/login');
        }
    })
    .catch(err=>next(err));
};
/**
 * User profile method
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.profile = (req, res, next)=>{
    let id = req.session.user;
    Promise.all([model.findById(id), Story.find({author: id})]) 
    .then(results=>{
        const [user, stories] = results;
        res.render('./user/profile', {user, stories})
    })
    .catch(err=>next(err));
};
/**
 * User logout method
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
exports.logout = (req, res, next)=>{
    req.session.destroy(err=>{
        if(err)
            return next(err);
        else
            res.redirect('/');
    });
};